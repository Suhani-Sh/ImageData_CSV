from app import db
from datetime import datetime

class ProcessingRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.String(100), unique=True, nullable=False)
    status = db.Column(db.String(20), default='Pending')
    webhook_url = db.Column(db.String(255), nullable=True)  
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.String(100), db.ForeignKey('processing_request.request_id'))
    product_name = db.Column(db.String(100), nullable=False)
    input_image_urls = db.Column(db.Text, nullable=False)
    output_image_urls = db.Column(db.Text, nullable=True)
