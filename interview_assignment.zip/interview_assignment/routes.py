from flask import request, jsonify
import uuid
from app import app, db, celery
from app.models import ProcessingRequest, Product
from app.tasks import process_images

@app.route('/upload', methods=['POST'])
def upload_csv():
    file = request.files['file']
    webhook_url = request.form.get('webhook_url')  # Get webhook URL from the request

    # Validate and process the CSV
    csv_data = validate_csv(file)
    if not csv_data:
        return jsonify({"error": "Invalid CSV format"}), 400

    # Create a unique request ID
    request_id = str(uuid.uuid4())

    # Save initial request data in the database with the webhook URL
    processing_request = ProcessingRequest(request_id=request_id, status='Pending', webhook_url=webhook_url)
    db.session.add(processing_request)
    db.session.commit()

    # Start async image processing task
    process_images.delay(request_id, csv_data)
    
    return jsonify({"request_id": request_id}), 202


@app.route('/status/<request_id>', methods=['GET'])
def check_status(request_id):
    # Fetch request from the database
    processing_request = ProcessingRequest.query.filter_by(request_id=request_id).first()
    if not processing_request:
        return jsonify({"error": "Invalid request ID"}), 404
    
    return jsonify({"status": processing_request.status})


    import csv
from flask import Response

@app.route('/download/<request_id>', methods=['GET'])
def download_output_csv(request_id):
    # Fetch the products associated with the request ID
    products = Product.query.filter_by(request_id=request_id).all()
    if not products:
        return jsonify({"error": "Invalid request ID or no products found"}), 404

    # Create the output CSV
    def generate():
        data = StringIO()
        writer = csv.writer(data)
        # Write header
        writer.writerow(['S. No.', 'Product Name', 'Input Image Urls', 'Output Image Urls'])
        yield data.getvalue()
        data.seek(0)
        data.truncate(0)

        # Write product data rows
        for idx, product in enumerate(products, 1):
            writer.writerow([idx, product.product_name, product.input_image_urls, product.output_image_urls])
            yield data.getvalue()
            data.seek(0)
            data.truncate(0)

    # Return the response as a CSV
    response = Response(generate(), mimetype='text/csv')
    response.headers.set("Content-Disposition", "attachment", filename=f"output_{request_id}.csv")
    return response

