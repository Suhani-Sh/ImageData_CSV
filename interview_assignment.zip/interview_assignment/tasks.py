import os
import requests
from PIL import Image
from io import BytesIO
from app import celery, db
from app.models import ProcessingRequest, Product



@celery.task
def process_images(request_id, csv_data):
    # Process each product's images
    output_data = []
    for item in csv_data:
        product_name, input_urls = item['product_name'], item['input_image_urls']
        input_urls = input_urls.split(',')
        output_urls = []

        # Download and compress each image
        for url in input_urls:
            compressed_image_url = compress_image(url)
            output_urls.append(compressed_image_url)

        # Save processed data in the database
        product = Product(
            request_id=request_id,
            product_name=product_name,
            input_image_urls=','.join(input_urls),
            output_image_urls=','.join(output_urls)
        )
        db.session.add(product)
    
    # Update the processing request status to 'Completed'
    processing_request = ProcessingRequest.query.filter_by(request_id=request_id).first()
    processing_request.status = 'Completed'
    db.session.commit()

    # Trigger the webhook if a URL is provided
    if processing_request.webhook_url:
        try:
            requests.post(processing_request.webhook_url, json={"request_id": request_id, "status": "Completed"})
        except Exception as e:
            print(f"Failed to send webhook: {e}")

def compress_image(url):
    # Download image
    response = requests.get(url)
    img = Image.open(BytesIO(response.content))
    
    # Compress image (reduce quality by 50%)
    output = BytesIO()
    img.save(output, format="JPEG", quality=50)
    
    # In a real system, you'd upload this to a file storage service and return the URL
    return "compressed_" + url.split('/')[-1]
