import csv
from io import StringIO

def validate_csv(file):
    try:
        stream = StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_data = csv.DictReader(stream)
        
        data = []
        for row in csv_data:
            if not row['Product Name'] or not row['Input Image Urls']:
                return None
            data.append({
                'product_name': row['Product Name'],
                'input_image_urls': row['Input Image Urls']
            })
        return data
    except Exception as e:
        print(e)
        return None
