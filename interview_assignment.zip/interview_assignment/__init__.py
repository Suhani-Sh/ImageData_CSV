from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from celery import Celery

# Initialize Flask App
app = Flask(__name__)
app.config.from_object('config.Config')

# Initialize Database
db = SQLAlchemy(app)

# Initialize Celery for asynchronous task processing
def make_celery(app):
    celery = Celery(
        app.import_name,
        backend=app.config['CELERY_RESULT_BACKEND'],
        broker=app.config['CELERY_BROKER_URL']
    )
    celery.conf.update(app.config)
    return celery

celery = make_celery(app)

# Import routes
from app import routes
